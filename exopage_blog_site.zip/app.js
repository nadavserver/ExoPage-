
// ExoPage - Simple Blog + Q&A (stores data in localStorage)
// Hebrew UI, RTL. No server required: open index.html in browser.

const STORAGE_KEY = 'exopage_data_v1';

function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,6); }

function loadData(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(!raw) return {posts:[], questions:[]};
  try{ return JSON.parse(raw); } catch(e){ return {posts:[], questions:[]}; }
}
function saveData(data){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }

let state = loadData();

// --- UI helpers
const el = (id) => document.getElementById(id);
const pages = ['home','new-post','questions','new-question'];

function showPage(page){
  pages.forEach(p => {
    const node = el(p);
    if(node) node.style.display = (p===page ? '' : 'none');
  });
  document.querySelectorAll('.nav-btn').forEach(b=>{
    b.classList.remove('active');
  });
  const map = {'home':'nav-home','new-post':'nav-new-post','questions':'nav-questions','new-question':'nav-new-question'};
  const btn = el(map[page]);
  if(btn) btn.classList.add('active');
  renderAll();
}

// --- render posts
function renderAll(){
  renderPosts();
  renderQuestions();
}

function renderPosts(filter=''){
  const list = el('posts-list');
  list.innerHTML = '';
  const posts = state.posts.slice().reverse().filter(p=>{
    if(!filter) return true;
    const t = (p.title + ' ' + p.content).toLowerCase();
    return t.includes(filter.toLowerCase());
  });
  if(posts.length===0){
    list.innerHTML = '<div class="card">לא נמצאו פוסטים</div>';
    return;
  }
  posts.forEach(p=>{
    const item = document.createElement('article');
    item.className = 'card';
    item.innerHTML = `<h3>${escapeHtml(p.title)}</h3>
      <p>${escapeHtml(truncate(p.content,160))}</p>
      <div style="display:flex;gap:8px;justify-content:space-between;align-items:center">
        <div style="color:#6b7280;font-size:13px">פורסם: ${new Date(p.created).toLocaleString('he-IL')}</div>
        <div>
          <button class="small" data-id="${p.id}" data-action="view">צפה</button>
          <button class="small" data-id="${p.id}" data-action="delete">מחק</button>
        </div>
      </div>`;
    list.appendChild(item);
  });
}

function renderQuestions(){
  const list = el('questions-list');
  list.innerHTML = '';
  const qs = state.questions.slice().reverse();
  if(qs.length===0){
    list.innerHTML = '<div class="card">אין שאלות עדיין</div>';
    return;
  }
  qs.forEach(q=>{
    const item = document.createElement('article');
    item.className = 'card';
    const answersHtml = q.answers && q.answers.length ? '<ul>' + q.answers.map(a=>`<li><strong>${escapeHtml(a.name||'מישהו')}</strong>: ${escapeHtml(truncate(a.text,200))}</li>`).join('') + '</ul>' : '<div style="color:#6b7280">עדיין אין תשובות</div>';
    item.innerHTML = `<h3>${escapeHtml(q.title)}</h3>
      <p>${escapeHtml(truncate(q.content,300))}</p>
      <div style="display:flex;gap:8px;justify-content:space-between;align-items:center">
        <div style="color:#6b7280;font-size:13px">נשאל: ${new Date(q.created).toLocaleString('he-IL')}</div>
        <div>
          <button class="small" data-id="${q.id}" data-action="view-q">פתח</button>
          <button class="small" data-id="${q.id}" data-action="answer">ענה</button>
          <button class="small danger" data-id="${q.id}" data-action="delete-q">מחק</button>
        </div>
      </div>
      <div style="margin-top:8px">${answersHtml}</div>`;
    list.appendChild(item);
  });
}

// --- events
document.addEventListener('click', (e)=>{
  const view = e.target.getAttribute && e.target.getAttribute('data-action');
  if(view==='view'){
    const id = e.target.getAttribute('data-id');
    const p = state.posts.find(x=>x.id===id);
    if(p) openModal(`<h2>${escapeHtml(p.title)}</h2><div style="color:#6b7280;font-size:13px">פורסם: ${new Date(p.created).toLocaleString('he-IL')}</div><hr/><div style="margin-top:10px;white-space:pre-line">${escapeHtml(p.content)}</div>`);
  } else if(view==='delete'){
    const id = e.target.getAttribute('data-id');
    if(confirm('אתה בטוח שברצונך למחוק את הפוסט?')) {
      state.posts = state.posts.filter(x=>x.id!==id);
      saveData(state); renderAll();
    }
  } else if(view==='view-q'){
    const id = e.target.getAttribute('data-id');
    const q = state.questions.find(x=>x.id===id);
    if(q){
      const answers = (q.answers||[]).map(a=>`<div class="card" style="margin-bottom:8px"><strong>${escapeHtml(a.name||'מישהו')}</strong><div style="white-space:pre-line;margin-top:6px">${escapeHtml(a.text)}</div></div>`).join('');
      const body = `<h2>${escapeHtml(q.title)}</h2><div style="color:#6b7280;font-size:13px">נשאל: ${new Date(q.created).toLocaleString('he-IL')}</div><hr/><div style="margin-top:10px;white-space:pre-line">${escapeHtml(q.content)}</div><hr/><h3>תשובות</h3>${answers}<div style="margin-top:8px"><input id="answer-name" placeholder="שמך (אופציונלי)" style="width:100%;padding:8px;border-radius:8px;border:1px solid #e6e6ee;margin-bottom:8px" /><textarea id="answer-text" placeholder=\"כתוב תשובה...\"></textarea><div style="margin-top:8px"><button id="submit-answer" data-id="${q.id}">שלח תשובה</button></div></div>`;
      openModal(body);
    }
  } else if(view==='answer'){
    const id = e.target.getAttribute('data-id');
    const name = prompt('שם (רשות)') || '';
    const text = prompt('כתוב את התשובה שלך:');
    if(text && text.trim()){
      const q = state.questions.find(x=>x.id===id);
      if(q){
        q.answers = q.answers || [];
        q.answers.push({id: uid(), name: name.trim(), text: text.trim(), created: Date.now()});
        saveData(state); renderAll(); alert('תשובתך נשמרה!');
      }
    }
  } else if(view==='delete-q'){
    const id = e.target.getAttribute('data-id');
    if(confirm('אתה בטוח שברצונך למחוק את השאלה?')) {
      state.questions = state.questions.filter(x=>x.id!==id);
      saveData(state); renderAll();
    }
  }
});

// navigation
el('nav-home').addEventListener('click', ()=> showPage('home'));
el('nav-new-post').addEventListener('click', ()=> showPage('new-post'));
el('nav-questions').addEventListener('click', ()=> showPage('questions'));
el('nav-new-question').addEventListener('click', ()=> showPage('new-question'));
el('cancel-post').addEventListener('click', ()=> showPage('home'));
el('cancel-question').addEventListener('click', ()=> showPage('home'));

// save post
el('save-post').addEventListener('click', ()=>{
  const title = el('post-title').value.trim();
  const content = el('post-content').value.trim();
  if(!title || !content){ alert('אנא מלא כותרת ותוכן'); return; }
  state.posts.push({id: uid(), title, content, created: Date.now()});
  saveData(state);
  el('post-title').value = ''; el('post-content').value = '';
  alert('הפוסט פורסם!');
  showPage('home');
});

// save question
el('save-question').addEventListener('click', ()=>{
  const title = el('q-title').value.trim();
  const content = el('q-content').value.trim();
  if(!title || !content){ alert('אנא מלא כותרת ותוכן'); return; }
  state.questions.push({id: uid(), title, content, created: Date.now(), answers: []});
  saveData(state);
  el('q-title').value=''; el('q-content').value='';
  alert('השאלה פורסמה!');
  showPage('questions');
});

// modal handlers
function openModal(html){
  el('modal-body').innerHTML = html;
  el('modal').style.display = 'flex';
  // attach submit answer if exists
  const submit = document.getElementById('submit-answer');
  if(submit){
    submit.addEventListener('click', ()=>{
      const qid = submit.getAttribute('data-id');
      const name = document.getElementById('answer-name').value || '';
      const text = document.getElementById('answer-text').value || '';
      if(!text.trim()){ alert('כתוב תשובה'); return; }
      const q = state.questions.find(x=>x.id===qid);
      if(q){
        q.answers = q.answers || [];
        q.answers.push({id: uid(), name: name.trim(), text: text.trim(), created: Date.now()});
        saveData(state); renderAll(); closeModal(); alert('תשובתך נשמרה!');
      }
    });
  }
}
el('modal-close').addEventListener('click', closeModal);
function closeModal(){ el('modal').style.display = 'none'; el('modal-body').innerHTML=''; }

// search
el('search').addEventListener('input', (e)=> {
  const q = e.target.value.trim();
  renderPosts(q);
  // also could filter questions later
});

// export / import / clear
el('export-btn').addEventListener('click', ()=>{
  const dataStr = JSON.stringify(state, null, 2);
  const blob = new Blob([dataStr], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'exopage-data.json'; a.click();
  URL.revokeObjectURL(url);
});

el('import-btn').addEventListener('click', ()=> el('import-file').click());
el('import-file').addEventListener('change', (e)=>{
  const f = e.target.files[0];
  if(!f) return;
  const reader = new FileReader();
  reader.onload = ()=> {
    try{
      const json = JSON.parse(reader.result);
      if(confirm('האם לייבא ולשנות את הנתונים הקיימים? (הפעולה תחליף את הנתונים הנוכחיים)')){
        state = json;
        saveData(state); renderAll(); alert('ייבוא בוצע בהצלחה!');
      }
    }catch(err){ alert('קובץ לא תקין'); }
  };
  reader.readAsText(f);
});

el('clear-btn').addEventListener('click', ()=>{
  if(confirm('למחוק את כל הנתונים מהדפדפן?')) {
    state = {posts:[], questions:[]}; saveData(state); renderAll(); alert('נתונים נמחקו');
  }
});

// utilities
function truncate(s,len){ if(!s) return ''; return s.length>len ? s.slice(0,len-1)+'…' : s; }
function escapeHtml(unsafe) {
  return (unsafe||'').toString()
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

// init
renderAll();
showPage('home');
